import asyncio
import json
import tempfile
import unittest
import zipfile
from pathlib import Path
from unittest.mock import patch

from backend import agent, config, server, storage, transactions
from backend.errors import WorkError, error_payload
from backend.experience import compact_messages, diff_source
from backend.patcher import apply_operations, regions, set_style, PatchError
from scripts.package_release import build

HTML = '''<!doctype html><html><head><title>测试</title><style>
/* #region tokens */
:root{--color-primary:#0f766e;}
/* #endregion tokens */
</style></head><body>
<!-- #region markup-main -->
<button id="one" data-pid="按钮一">导出</button><button id="two">查询</button>
<!-- #endregion markup-main -->
<script>const note="/* #region not-a-marker */";</script></body></html>'''


def tool(name, args):
    return {'choices':[{'finish_reason':'tool_calls','message':{'tool_calls':[{'id':'call','function':{'name':name,'arguments':json.dumps(args)}}]}}]}


class OptimizationTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root_patch = patch.object(storage,'DATA_ROOT',Path(self.tmp.name))
        self.root_patch.start()
        self.pid = storage.create_project('整改验收')['id']
        (storage.project_dir(self.pid)/'source'/'index.html').write_text(HTML,'utf-8')
        self.page_id = storage.add_page(self.pid,'index.html')['id']

    def tearDown(self):
        transactions.PENDING.clear(); self.root_patch.stop(); self.tmp.cleanup()

    def run_model(self, responses, **kwargs):
        with patch('backend.agent.chat',side_effect=responses):
            return agent.run_agent(self.pid,self.page_id,'修改导出按钮','test-key','test-model',**kwargs)

    def test_inline_region_like_text_is_ignored(self):
        self.assertEqual(set(regions(HTML)), {'tokens','markup-main'})
        edited,_ = apply_operations(HTML,[{'action':'set_text','selector':'#one','value':'下载'}])
        self.assertEqual(edited,HTML.replace('>导出<','>下载<'))
        self.assertNotIn('fake',regions(HTML.replace('<title>测试</title>','<title>/* #region fake */</title>')))

    def test_style_whitelist_rejects_comment_quotes_and_complex_selectors(self):
        for selector in ['#one/*', '[id="one"]', '#one"', 'body, html', '#one;body', '#one\\2f *', ':has(script)']:
            with self.subTest(selector=selector), self.assertRaises(PatchError):
                set_style(HTML,selector,'font-size','16px')
        for selector in ['#one','[data-pid="按钮一"]','body > button:nth-of-type(1)','body button#one']:
            self.assertIn('font-size: 16px',set_style(HTML,selector,'font-size','16px'))

    def test_length_finish_reason_stops_before_any_patch(self):
        response = tool('apply_operations',{'operations':[{'action':'set_text','selector':'#one','value':'损坏'}]})
        response['choices'][0]['finish_reason']='length'
        with self.assertRaises(WorkError) as exc: self.run_model([response])
        self.assertEqual(exc.exception.code,'output_limit')
        self.assertEqual(storage.read_page(self.pid,self.page_id),HTML)
        self.assertFalse(transactions.PENDING)

    def test_bad_json_is_explicit_and_never_applied_as_empty_object(self):
        bad = tool('apply_operations',{})
        bad['choices'][0]['message']['tool_calls'][0]['function']['arguments']='{"operations":['
        events=[]
        result=self.run_model([bad,tool('report_result',{'summary':'这次未修改，请重新点选。','annotations':[]})],on_event=events.append)
        self.assertFalse(result['changed'])
        self.assertEqual(events[1]['type'],'step_error')
        self.assertIn('完整 JSON',result['tool_log'][0]['output']['error'])

    def test_unexpected_exception_is_logged_and_not_retried_as_patch_failure(self):
        response=tool('apply_operations',{'operations':[{'action':'set_text','selector':'#one','value':'下载'}]})
        with patch('backend.agent.apply_operations',side_effect=RuntimeError('fixture programming bug')):
            with self.assertLogs('backend.agent',level='ERROR') as logs, self.assertRaises(WorkError) as exc:
                self.run_model([response])
        self.assertEqual(exc.exception.code,'internal')
        self.assertIn('fixture programming bug','\n'.join(logs.output))

    def test_read_region_fallback_works_after_first_failed_patch(self):
        responses=[tool('apply_operations',{'operations':[{'action':'set_text','selector':'#missing','value':'下载'}]}),
                   tool('read_region',{'name':'markup-main'}),
                   tool('apply_operations',{'operations':[{'action':'replace_region','region':'markup-main','value':'\n<button id="one">下载</button>\n'}]}),
                   tool('report_result',{'summary':'导出按钮已改为下载。','annotations':[]})]
        result=self.run_model(responses)
        self.assertTrue(result['changed'])
        self.assertIn('下载',transactions.get(result['pending_id'])['after'])

    def test_old_tool_results_are_compacted_without_losing_call_pairs(self):
        messages=[{'role':'system','content':'规则'}]
        for i in range(9):
            messages.extend([{'role':'assistant','tool_calls':[{'id':str(i)}]}, {'role':'tool','tool_call_id':str(i),'content':json.dumps({'content':'原文'*6000})}])
        compact_messages(messages)
        self.assertLess(sum(len(m.get('content','')) for m in messages),65000)
        self.assertEqual([m['tool_call_id'] for m in messages if m['role']=='tool'],[str(i) for i in range(9)])
        self.assertIn('context_compacted',messages[2]['content'])

    def test_diff_only_contains_changed_hunk_and_context(self):
        before='\n'.join(f'line {i}' for i in range(40)); after=before.replace('line 20','changed')
        diff=diff_source(before,after)
        self.assertEqual((diff['additions'],diff['deletions']),(1,1))
        self.assertEqual(len(diff['hunks'][0]['lines']),6)
        self.assertNotIn('line 0',str(diff))

    def test_partial_annotations_stay_active_until_explicit_completion(self):
        anns=[storage.add_annotation(self.pid,self.page_id,{'selector':selector,'note':'调整'}) for selector in ['#one','#two']]
        result=self.run_model([tool('apply_operations',{'operations':[{'action':'set_text','selector':'#one','value':'下载'}]}),
            tool('report_result',{'summary':'导出按钮改为下载。','annotations':[{'id':anns[0]['id'],'status':'completed'}, {'id':anns[1]['id'],'status':'partial','reason':'查询行为需要确认'}]})])
        self.assertEqual(len(storage.active_annotations(storage.load_meta(self.pid),self.page_id)),2)
        transactions.commit(result['pending_id'],[],True)
        self.assertEqual([a['id'] for a in storage.active_annotations(storage.load_meta(self.pid),self.page_id)],[anns[1]['id']])
        self.assertEqual(result['report']['annotations'][1]['number'],2)

    def test_question_does_not_change_file_version_or_annotations(self):
        ann=storage.add_annotation(self.pid,self.page_id,{'selector':'#one','note':'换布局'})
        result=self.run_model([tool('ask_user',{'question':'整块改成卡片，还是每一行改成卡片？','options':['整块','每一行']})])
        self.assertFalse(result['changed'])
        self.assertEqual(len(result['clarification']['options']),2)
        self.assertEqual(storage.get_page(storage.load_meta(self.pid),self.page_id)['version'],1)
        self.assertEqual(storage.active_annotations(storage.load_meta(self.pid),self.page_id)[0]['id'],ann['id'])

    def test_mixed_manual_ai_manual_undo_is_chronological(self):
        sources=[HTML,HTML.replace('导出','下载'),HTML.replace('导出','导出清单'),HTML.replace('导出','保存')]
        ids=[]
        for i,kind in enumerate(['manual','agent','manual']):
            candidate=transactions.stage(self.pid,self.page_id,sources[i],sources[i+1],'步骤',kind)
            ids.append(transactions.commit(candidate['pending_id'],[],True)['change_id'])
        with self.assertRaises(PatchError): transactions.undo(self.pid,self.page_id,ids[0])
        for expected in reversed(sources[:-1]):
            candidate=transactions.undo(self.pid,self.page_id)
            transactions.commit(candidate['pending_id'],[],True)
            self.assertEqual(storage.read_page(self.pid,self.page_id),expected)
        page=storage.get_page(storage.load_meta(self.pid),self.page_id)
        self.assertEqual(page['undo_stack'],[])
        self.assertEqual(len(page['edit_history']),6)

    def test_stream_emits_steps_and_completion_without_network_model(self):
        settings={**config.DEFAULT,'api_key':'fake-key'}
        def run(*args,**kwargs):
            kwargs['on_event']({'type':'step_start','id':'1','label':'读取页面结构'})
            kwargs['on_event']({'type':'step_done','id':'1','label':'读取页面结构'})
            return {'changed':False}
        async def collect(response):
            return ''.join([chunk async for chunk in response.body_iterator])
        with patch('backend.server.config.load',return_value=settings),patch('backend.server.run_agent',side_effect=run):
            body=asyncio.run(collect(server.agent_stream(self.pid,server.AgentIn(page_id=self.page_id,message='修改'))))
        self.assertIn('step_start',body);self.assertIn('step_done',body);self.assertIn('complete',body)
        self.assertNotIn('fake-key',body)

    def test_max_tokens_is_configurable_and_validated(self):
        with patch.object(config,'CONFIG_FILE',Path(self.tmp.name)/'config.json'):
            self.assertEqual(config.save({'max_tokens':24000})['max_tokens'],24000)
            with self.assertRaises(ValueError): config.save({'max_tokens':0})

    def test_packaging_excludes_dependencies_local_data_and_editor_files(self):
        root=Path(self.tmp.name)/'package'; root.mkdir()
        for directory in ['.venv','.idea','data','frontend/node_modules','frontend/dist']:
            folder=root/directory; folder.mkdir(parents=True,exist_ok=True); (folder/'fixture.txt').write_text('fixture')
        archive=build(Path(self.tmp.name)/'result.zip',root)
        with zipfile.ZipFile(archive) as zf:
            self.assertEqual(zf.namelist(),['prototype-agent/frontend/dist/fixture.txt'])

    def test_version_and_key_storage_are_documented_consistently(self):
        root = Path(__file__).resolve().parents[1]
        readme = (root/'README.md').read_text('utf-8')
        package = json.loads((root/'frontend'/'package.json').read_text('utf-8'))
        self.assertEqual(server.health()['version'], config.VERSION)
        self.assertEqual(server.app.version, config.VERSION)
        self.assertIn(f'v{config.VERSION}', readme.splitlines()[0])
        self.assertTrue(package['version'].startswith(config.VERSION + '.'))
        # The README used to promise browser storage that the server no longer uses.
        self.assertNotIn('localStorage', readme)
        self.assertIn('data/config.json', readme)
        for stale in ['v4.0', 'v4 ']:
            self.assertNotIn(stale, readme)

    def test_precise_spa_prefix_does_not_shadow_preview_named_frontend_route(self):
        self.assertTrue(str(server.spa('preview-notes').path).endswith('index.html'))
        for path in ['api/nope','preview/missing','preview-assets/missing']:
            with self.assertRaises(server.HTTPException): server.spa(path)


if __name__=='__main__': unittest.main()
