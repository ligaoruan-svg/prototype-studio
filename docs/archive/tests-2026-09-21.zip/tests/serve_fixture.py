"""Isolated UI acceptance fixture. No real API, credentials or user project writes."""
import json
import re
import tempfile
import time
from pathlib import Path
import uvicorn
from backend import storage, config, agent
from backend.errors import WorkError

fixture_dir = tempfile.TemporaryDirectory(prefix='prototype-acceptance-')
storage.DATA_ROOT = Path(fixture_dir.name)/'projects'
storage.DATA_ROOT.mkdir()
config.CONFIG_FILE = Path(fixture_dir.name)/'config.json'
config.save({'api_key':'isolated-fixture-key','base_url':'https://example.invalid','model':'模拟模型 · 不联网','supports_vision':True})
project = storage.create_project('隔离验收 · 模拟模型')
source = '''<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><style>
/* #region tokens */
:root{--color-primary:#0f766e;}
/* #endregion tokens */
body{font:16px/1.7 system-ui;margin:0;color:#20302b;background:#f7faf8}header{padding:30px;background:white;border-bottom:1px solid #dde5df}main{padding:30px}button{background:var(--color-primary);border:0;color:white;border-radius:6px;padding:12px 20px;margin-right:14px;cursor:pointer}.spacer{height:1500px;padding-top:60px;color:#74867b}.nested{height:200px;overflow:auto;background:white;border:1px solid #dce5df;padding:16px}.nested>div{height:650px}
</style></head><body><header><h1>交互验收页面</h1><p>当前使用模拟模型，不会调用任何外部接口。</p></header><main>
<!-- #region markup-main -->
<button id="top-action" data-pid="top-action">顶部按钮</button><div class="nested" id="nested"><div>可滚动容器</div><button id="nested-action">容器内按钮</button></div><div class="spacer">滚动到页面底部，测试修改后位置保持。</div><h2>底部操作区</h2><button id="action" data-pid="bottom-action">导出</button><button id="filter">查询</button>
<!-- #endregion markup-main -->
</main><script>const example="/* #region example-only */";</script></body></html>'''
(storage.project_dir(project['id'])/'source'/'index.html').write_text(source,'utf-8')
storage.add_page(project['id'],'index.html','交互验收页面')


def answer(name,args):
    return {'choices':[{'finish_reason':'tool_calls','message':{'tool_calls':[{'id':'fixture-call','function':{'name':name,'arguments':json.dumps(args,ensure_ascii=False)}}]}}], 'usage':{'total_tokens':128}}


def fake_chat(key,model,messages,*args,**kwargs):
    time.sleep(1.2)
    kickoff=next(m['content'] for m in messages if m['role']=='user')
    if isinstance(kickoff,list): kickoff=kickoff[0]['text']
    request=kickoff.split('用户本轮要求：')[-1]
    if '网络失败' in request: raise WorkError('network','模拟网络连接失败')
    if '超长输出' in request: return {'choices':[{'finish_reason':'length','message':{'content':'未完成的输出'}}]}
    if '卡片' in request: return answer('ask_user',{'question':'整块区域改成卡片，还是每一行分别改成卡片？','options':['整块改成卡片','每行一张卡片']})
    calls=[c['function']['name'] for m in messages for c in m.get('tool_calls',[])]
    if not calls: return answer('inspect_page',{})
    if 'apply_operations' not in calls:
        ops=[{'action':'set_text','selector':'#action','value':'导出清单'}]
        if '检查失败' in request: ops.append({'action':'append_script','value':'throw new Error("模拟检查失败");'})
        return answer('apply_operations',{'operations':ops})
    if 'verify_page' not in calls: return answer('verify_page',{'assertions':[{'selector':'#action','contains':'导出清单'}]})
    ids=re.findall(r'意见 \d+ id=(ann_[a-f0-9]+)',kickoff)
    results=[{'id':ident,'status':'completed' if i==0 else 'unprocessed','reason':'' if i==0 else '模拟待确认意见'} for i,ident in enumerate(ids)]
    return answer('report_result',{'summary':'导出按钮的文字已改为“导出清单”。','annotations':results,'assumptions':[]})


agent.chat=fake_chat
from backend.server import app
if __name__=='__main__':
    try: uvicorn.run(app,host='127.0.0.1',port=5175,log_level='warning')
    finally: fixture_dir.cleanup()
