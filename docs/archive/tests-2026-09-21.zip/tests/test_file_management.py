import asyncio
import io
import tempfile
import unittest
import zipfile
from pathlib import Path
from unittest.mock import patch

from backend import storage, transactions, server
from backend.patcher import PatchError

HTML = '<!doctype html><html><head><title>文件测试</title></head><body><p>保留原文</p></body></html>'


class FileManagementTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root_patch = patch.object(storage, 'DATA_ROOT', Path(self.tmp.name))
        self.root_patch.start()
        self.project = storage.create_project('测试文件管理')
        self.pid = self.project['id']
        self.source = storage.project_dir(self.pid) / 'source'
        self.pages = []
        for name in ['index.html', 'detail.html']:
            (self.source / name).write_text(HTML, 'utf-8')
            self.pages.append(storage.add_page(self.pid, name))
        (self.source / 'shared.css').write_text('body{color:green}', 'utf-8')

    def tearDown(self):
        transactions.PENDING.clear()
        self.root_patch.stop()
        self.tmp.cleanup()

    def test_project_delete_is_recoverable_and_never_removes_source(self):
        before = storage.load_meta(self.pid)
        storage.trash_item(self.pid)
        self.assertEqual(storage.list_projects(), [])
        with self.assertRaises(FileNotFoundError):
            storage.load_meta(self.pid)
        self.assertEqual((self.source / 'index.html').read_text('utf-8'), HTML)
        self.assertEqual(storage.list_trash()[0]['project_id'], self.pid)
        storage.restore_item(self.pid)
        self.assertEqual(storage.load_meta(self.pid)['pages'], before['pages'])
        self.assertEqual(storage.list_trash(), [])

    def test_page_delete_and_restore_preserve_id_path_and_history(self):
        original = storage.get_page(storage.load_meta(self.pid), self.pages[0]['id']).copy()
        storage.trash_item(self.pid, original['id'])
        listed = storage.list_projects()[0]
        self.assertEqual(listed['page_count'], 1)
        self.assertEqual(listed['pages'][0]['id'], self.pages[1]['id'])
        with self.assertRaises(KeyError):
            storage.read_page(self.pid, original['id'])
        storage.restore_item(self.pid, original['id'])
        restored = storage.get_page(storage.load_meta(self.pid), original['id'])
        for key in ['id', 'path', 'version', 'versions']:
            self.assertEqual(restored[key], original[key])
        self.assertEqual(storage.read_page(self.pid, original['id']), HTML)

    def test_restore_project_does_not_resurrect_previously_deleted_page(self):
        storage.trash_item(self.pid, self.pages[0]['id'])
        storage.trash_item(self.pid)
        self.assertEqual([item['kind'] for item in storage.list_trash()], ['project'])
        with self.assertRaises(ValueError):
            storage.restore_item(self.pid, self.pages[0]['id'])
        storage.restore_item(self.pid)
        self.assertEqual([item['kind'] for item in storage.list_trash()], ['page'])
        self.assertEqual(storage.list_projects()[0]['page_count'], 1)

    def test_rename_changes_labels_not_source_or_paths(self):
        storage.rename_item(self.pid, '新的项目名称')
        storage.rename_item(self.pid, '新的页面名称', self.pages[0]['id'])
        meta = storage.load_meta(self.pid)
        self.assertEqual(meta['name'], '新的项目名称')
        self.assertEqual(meta['pages'][0]['title'], '新的页面名称')
        self.assertEqual(meta['pages'][0]['path'], 'index.html')
        self.assertEqual(storage.read_page(self.pid, self.pages[0]['id']), HTML)
        with self.assertRaises(ValueError):
            storage.rename_item(self.pid, '   ')

    def test_deleted_page_hidden_from_api_navigation_assets_and_export(self):
        server.delete_page(self.pid, self.pages[0]['id'])
        self.assertEqual(len(server.get_project(self.pid)['pages']), 1)
        self.assertEqual(server.resolve_page(self.pid, 'index.html')['page_id'], None)
        with self.assertRaises(server.HTTPException) as exc:
            server.preview_asset(self.pid, 'index.html')
        self.assertEqual(exc.exception.status_code, 404)
        response = server.export_project(self.pid)
        async def collect():
            return b''.join([chunk async for chunk in response.body_iterator])
        with zipfile.ZipFile(io.BytesIO(asyncio.run(collect()))) as archive:
            self.assertNotIn('index.html', archive.namelist())
            self.assertIn('detail.html', archive.namelist())
            self.assertIn('shared.css', archive.namelist())

    def test_delete_invalidates_pending_edit_even_after_restore(self):
        page_id = self.pages[0]['id']
        candidate = transactions.stage(self.pid, page_id, HTML, HTML.replace('保留原文', '不能复活'), '旧请求')
        server.delete_project(self.pid)
        server.restore_item(server.RestoreItemIn(project_id=self.pid))
        with self.assertRaises(PatchError):
            transactions.commit(candidate['pending_id'], [], True)
        self.assertEqual(storage.read_page(self.pid, page_id), HTML)

    def test_last_page_can_be_restored_to_empty_project(self):
        for page in self.pages:
            storage.trash_item(self.pid, page['id'])
        self.assertEqual(server.get_project(self.pid)['pages'], [])
        self.assertEqual(storage.list_projects()[0]['page_count'], 0)
        storage.restore_item(self.pid, self.pages[0]['id'])
        self.assertEqual(len(server.get_project(self.pid)['pages']), 1)


if __name__ == '__main__':
    unittest.main()
