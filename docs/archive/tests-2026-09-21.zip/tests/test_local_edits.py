import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from backend import storage, transactions, config
from backend.agent import run_agent
from backend.bridge import build_bridge
from backend.errors import WorkError
from backend.patcher import apply_operations, verify_source, PatchError, locate

SAMPLE = """<!doctype html>\r
<html lang='zh-CN'><head><title>测试</title><style>
/* #region tokens */
:root { --color-primary: #0f766e; }
/* #endregion tokens */
</style></head><body>
<!-- #region markup-main -->
<button id='one' data-pid='main-btn' class='btn'>你好 &amp; 世界</button>
<button id='two' class='btn'>保持不动</button>
<!-- #endregion markup-main -->
<script>const sample = '<button>动态</button>';</script></body></html>"""


class PatchTests(unittest.TestCase):
    def test_text_preserves_every_other_character(self):
        result, _ = apply_operations(SAMPLE, [{'action':'set_text','selector':'#one','value':'完成 <3'}])
        self.assertEqual(result, SAMPLE.replace('你好 &amp; 世界', '完成 &lt;3'))

    def test_source_replacement_does_not_serialize_markup(self):
        result, _ = apply_operations(SAMPLE, [{'action':'replace_source_text','old':"const sample = '<button>动态</button>';",'new':"const sample = '<button>新内容</button>';"}])
        self.assertEqual(result, SAMPLE.replace('动态', '新内容'))

    def test_nonunique_selector_and_find_rejected(self):
        for operation in [{'action':'remove','selector':'.btn'}, {'action':'replace_source_text','old':'button','new':'a'}]:
            with self.assertRaises(PatchError):
                apply_operations(SAMPLE, [operation])

    def test_region_constrains_search(self):
        with self.assertRaises(PatchError):
            apply_operations(SAMPLE, [{'action':'replace_source_text','region':'tokens','old':'保持不动','new':'错误'}])

    def test_region_marker_cannot_disappear(self):
        with self.assertRaises(PatchError):
            apply_operations(SAMPLE, [{'action':'replace_source_text','old':'<!-- #region markup-main -->','new':''}])

    def test_set_attribute_changes_only_opening_tag(self):
        result, _ = apply_operations(SAMPLE, [{'action':'set_attr','selector':'#one','name':'title','value':'a " b'}])
        self.assertEqual(result, SAMPLE.replace("class='btn'>你好", "class='btn' title=\"a &quot; b\">你好", 1))

    def test_styles_update_single_rule(self):
        source, _ = apply_operations(SAMPLE, [{'action':'set_style','selector':'#one','name':'font-size','value':'16px'}])
        updated, _ = apply_operations(source, [{'action':'set_style','selector':'#one','name':'font-size','value':'20px'}])
        self.assertEqual(updated.count('/* edit:'), 1)
        self.assertIn('#one { font-size: 20px !important; }', updated)
        self.assertIn("<button id='two' class='btn'>保持不动</button>", updated)

    def test_invalid_javascript_and_duplicate_pid_fail(self):
        self.assertFalse(verify_source(SAMPLE.replace('const sample =', 'const ='))['ok'])
        self.assertFalse(verify_source(SAMPLE.replace("id='two'", "id='two' data-pid='main-btn'"))['ok'])

    def test_dynamic_dom_not_matched_as_static_node(self):
        with self.assertRaises(PatchError):
            locate(SAMPLE, 'button:not([id])')

    def test_whole_document_replacement_is_rejected(self):
        for operation in [
            {'action':'set_html', 'selector':'body', 'value':'重写'},
            {'action':'replace_source_text', 'old':SAMPLE, 'new':SAMPLE.replace('保持不动', '重写')},
        ]:
            with self.assertRaises(PatchError):
                apply_operations(SAMPLE, [operation])

    def test_early_inspection_bridge_has_valid_javascript(self):
        preview = SAMPLE.replace('<head>', '<head>' + build_bridge('p_0000000000', 'page_demo'))
        self.assertTrue(verify_source(preview)['ok'])


class TransactionTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root_patch = patch.object(storage, 'DATA_ROOT', Path(self.tmp.name))
        self.root_patch.start()
        project = storage.create_project('隔离测试')
        self.pid = project['id']
        (storage.project_dir(self.pid) / 'source' / 'index.html').write_text(SAMPLE, 'utf-8')
        self.page_id = storage.add_page(self.pid, 'index.html')['id']

    def tearDown(self):
        transactions.PENDING.clear()
        self.root_patch.stop()
        self.tmp.cleanup()

    def test_candidate_is_not_written_before_runtime_check(self):
        candidate = transactions.stage(self.pid, self.page_id, SAMPLE, SAMPLE.replace('保持不动','变化'), '测试')
        self.assertEqual(storage.read_page(self.pid, self.page_id), SAMPLE)
        with self.assertRaises(PatchError):
            transactions.commit(candidate['pending_id'], ['ReferenceError: missing'], True)
        self.assertEqual(storage.read_page(self.pid, self.page_id), SAMPLE)

    def test_reject_commit_without_runtime_handshake(self):
        candidate = transactions.stage(self.pid, self.page_id, SAMPLE, SAMPLE.replace('保持不动','变化'), '测试')
        with self.assertRaises(PatchError):
            transactions.commit(candidate['pending_id'], [], False)

    def test_commit_and_multiple_manual_undo(self):
        second = SAMPLE.replace('保持不动', '第一步')
        third = second.replace('第一步', '第二步')
        for before, after in [(SAMPLE, second), (second, third)]:
            candidate = transactions.stage(self.pid, self.page_id, before, after, '手动')
            transactions.commit(candidate['pending_id'], [], True)
        for expected in [second, SAMPLE]:
            candidate = transactions.undo(self.pid, self.page_id)
            transactions.commit(candidate['pending_id'], [], True)
            self.assertEqual(storage.read_page(self.pid, self.page_id), expected)
        # Unified undo is recorded as a new version without losing the snapshots.
        self.assertEqual(storage.get_page(storage.load_meta(self.pid), self.page_id)['version'], 3)

    def test_concurrent_candidate_cannot_overwrite_saved_change(self):
        a = transactions.stage(self.pid, self.page_id, SAMPLE, SAMPLE.replace('保持不动','甲'), '甲')
        b = transactions.stage(self.pid, self.page_id, SAMPLE, SAMPLE.replace('保持不动','乙'), '乙')
        transactions.commit(a['pending_id'], [], True)
        with self.assertRaises(PatchError):
            transactions.commit(b['pending_id'], [], True)
        self.assertIn('甲', storage.read_page(self.pid, self.page_id))

    def test_agent_tool_edit_waits_for_runtime_before_version(self):
        calls = [
            {'choices':[{'message':{'tool_calls':[{'id':'one','function':{'name':'apply_operations','arguments':json.dumps({'operations':[{'action':'set_text','selector':'#two','value':'已修改'}]})}}]}}], 'usage':{'total_tokens':12}},
            {'choices':[{'message':{'content':'已修改指定按钮。'}}], 'usage':{'total_tokens':8}},
        ]
        with patch('backend.agent.chat', side_effect=calls):
            result = run_agent(self.pid, self.page_id, '修改按钮文字', 'test-key', 'test-model')
        self.assertEqual(result['usage']['total_tokens'], 20)
        self.assertEqual(storage.read_page(self.pid, self.page_id), SAMPLE)
        transactions.commit(result['pending_id'], [], True)
        self.assertEqual(storage.get_page(storage.load_meta(self.pid), self.page_id)['version'], 2)
        self.assertIn('已修改', storage.read_page(self.pid, self.page_id))

    def test_failed_agent_never_marks_annotations_or_commits(self):
        annotation = storage.add_annotation(self.pid, self.page_id, {'selector':'#one','note':'修改'})
        bad = {'choices':[{'message':{'tool_calls':[{'id':'bad','function':{'name':'apply_operations','arguments':json.dumps({'operations':[{'action':'set_text','selector':'.missing','value':'无'}]})}}]}}]}
        with patch('backend.agent.chat', return_value=bad), self.assertRaises(WorkError):
            run_agent(self.pid, self.page_id, '修改', 'test-key', 'test-model')
        self.assertEqual(storage.read_page(self.pid, self.page_id), SAMPLE)
        self.assertEqual(storage.active_annotations(storage.load_meta(self.pid), self.page_id)[0]['id'], annotation['id'])

    def test_public_configuration_does_not_return_key(self):
        with patch.object(config, 'CONFIG_FILE', Path(self.tmp.name) / 'config.json'):
            result = config.save({'base_url':'https://example.com/v1','model':'vision-model','api_key':'test-secret','supports_vision':True})
            self.assertNotIn('api_key', result)
            self.assertNotIn('test-secret', json.dumps(result))
            self.assertEqual(config.CONFIG_FILE.stat().st_mode & 0o777, 0o600)
            self.assertTrue(result['supports_vision'])

    def test_region_annotations_keep_each_target_in_agent_context(self):
        from backend.server import AnnotationIn
        payload = AnnotationIn(selector='body', note='只调整框内按钮', kind='region',
            bounds={'left':0,'top':0,'right':300,'bottom':200},
            targets=[{'selector':'#one','text':'你好'}, {'selector':'#two','text':'保持不动'}])
        saved = storage.add_annotation(self.pid, self.page_id, payload.model_dump())
        self.assertEqual(len(saved['targets']), 2)
        self.assertEqual(saved['kind'], 'region')
        calls = [
            {'choices':[{'message':{'tool_calls':[{'id':'one','function':{'name':'apply_operations','arguments':json.dumps({'operations':[{'action':'set_text','selector':'#two','value':'已修改'}]})}}]}}]},
            {'choices':[{'message':{'content':'已修改指定按钮。'}}]},
        ]
        with patch('backend.agent.chat', side_effect=calls) as model_call:
            result = run_agent(self.pid, self.page_id, '调整框选区域', 'test-key', 'test-model')
        kickoff = model_call.call_args_list[0].args[2][1]['content']
        self.assertIn('selector=#one', kickoff)
        self.assertIn('selector=#two', kickoff)
        self.assertIn('只调整框内按钮', kickoff)
        self.assertEqual(storage.active_annotations(storage.load_meta(self.pid), self.page_id)[0]['id'], saved['id'])
        transactions.commit(result['pending_id'], [], True)
        # A free-form completion no longer silently consumes every annotation.
        self.assertEqual(storage.active_annotations(storage.load_meta(self.pid), self.page_id)[0]['id'], saved['id'])

    def test_screenshot_uses_multimodal_content_and_normalized_region_notes(self):
        reference = {'data_url':'data:image/png;base64,dGVzdA==', 'regions':[{'x':.1,'y':.2,'w':.3,'h':.4,'note':'主按钮调整为绿色'}]}
        with patch('backend.agent.chat', return_value={'choices':[{'message':{'content':'这是参考图。'}}]}) as model_call:
            run_agent(self.pid, self.page_id, '了解这张图', 'test-key', 'test-model', reference=reference)
        content = model_call.call_args.args[2][1]['content']
        self.assertEqual(content[1]['type'], 'image_url')
        self.assertEqual(content[1]['image_url']['url'], reference['data_url'])
        self.assertIn('主按钮调整为绿色', content[0]['text'])
        self.assertIn('"x": 0.1', content[0]['text'])
        self.assertEqual(storage.read_page(self.pid, self.page_id), SAMPLE)


if __name__ == '__main__':
    unittest.main()
